package com.example.fa2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Feedback extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        EditText etml = findViewById(R.id.etml);
    Button btngoback2 = findViewById(R.id.btngoback2);
        btngoback2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotToHome();
            }
        });
        Button btngoback = findViewById(R.id.btngoback);
        btngoback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareData(etml.getText().toString());
            }
        });
    }
    public void gotToHome(){
        Intent b = new Intent(getApplicationContext(),ThirdScreen.class);
        startActivity(b);
    }
    public void shareData(String data){
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");

        //Additional info
        i.putExtra(Intent.EXTRA_SUBJECT,"This is a Sample Email");
        i.putExtra(Intent.EXTRA_TEXT,"Hello World," + data + "!!!");

        startActivity(Intent.createChooser(i,"Choose a platform"));
    }
}

