package com.example.fa2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ThirdScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_screen);

        Intent j = getIntent();
        Intent b = getIntent();
        String fn = j.getStringExtra("fn");
        String ln = j.getStringExtra("ln");
        String email = j.getStringExtra("email");
        String Gender = j.getStringExtra("gender");
        TextView tvwelcome =findViewById(R.id.tvwelcome);
        Button btnview = findViewById(R.id.btnview);
        Button btnsend = findViewById(R.id.btnsend);
        Button button3 = findViewById(R.id.button3);

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotToMain();
            }
        });
        btnview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotToView(fn,ln,email,Gender);
            }
        });
        btnsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotToFeedback();
            }
        });



        if (Gender.equals("Female")){
            tvwelcome.setText("WELCOME, Ms. "+fn+ " "+ln);
        } else if (Gender.equals("Male")) {
            tvwelcome.setText("WELCOME, Mr. "+fn+ " "+ln);
        }

    }
    public void gotToView(String fn, String ln, String email, String Gender){
        Intent j = new Intent(getApplicationContext(),ViewProfile.class);
        j.putExtra("fn",fn);
        j.putExtra("ln",ln);
        j.putExtra("email",email);
        j.putExtra("gender",Gender);
        startActivity(j);
    }
    public void gotToMain(){
        Intent a = new Intent(getApplicationContext(),SecondScreen.class);
        startActivity(a);
    }
    public void gotToFeedback(){
        Intent u = new Intent(getApplicationContext(),Feedback.class);
        startActivity(u);
    }
}