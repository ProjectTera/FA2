package com.example.fa2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ViewProfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);

        Intent j = getIntent();
        String fn = j.getStringExtra("fn");
        String ln = j.getStringExtra("ln");
        String email = j.getStringExtra("email");
        String Gender = j.getStringExtra("gender");

        TextView TextView5 =findViewById(R.id.textView5);
        TextView TextView4 =findViewById(R.id.textView4);
        TextView TextView8 =findViewById(R.id.textView8);
        Button btnback = findViewById(R.id.btnback);
        ImageView ivprofile = findViewById(R.id.ivprofile);
        TextView5.setText(" "+fn);
        TextView4.setText(" "+ln);
        TextView8.setText(" "+email);

        if (Gender.equals("Female")){
        ivprofile.setImageResource(R.drawable.ms);
        } else if (Gender.equals("Male")) {
            ivprofile.setImageResource(R.drawable.mr);
        }
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotToHome();
            }
        });
    }

    public void gotToHome(){
        Intent b = new Intent(getApplicationContext(),ThirdScreen.class);
        startActivity(b);
    }
}