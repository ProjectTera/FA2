package com.example.lima_fa2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Feedback extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        EditText feedbackTxt = findViewById(R.id.feedbackTxt);
        Button btnSubmit = findViewById(R.id.btnSubmit);
        Button btnCancel = findViewById(R.id.btnCancel);

        Bundle information = getIntent().getExtras();
        String firstname2 = information.getString("x_fname2");
        String lastname2 = information.getString("x_lname2");
        String emails2 = information.getString("x_email2");
        String gender2 = information.getString("x_gender2");


        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendEmail(feedbackTxt.getText().toString(), emails2, lastname2, firstname2, gender2);
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gobackerz = new Intent(getApplicationContext(), HomePage.class);
                startActivity(gobackerz);
            }
        });
    }

    public void sendEmail(String dataEmail, String emailer, String lastnamer, String firstnamer, String genderer){
        Intent send = new Intent(Intent. ACTION_SEND);
        send.setType("text/plain");

        send.putExtra(Intent.EXTRA_EMAIL, emailer);

        if(genderer.equalsIgnoreCase("MALE")){
            send.putExtra(Intent.EXTRA_SUBJECT, "Feedback from Mr." + firstnamer + lastnamer);
        }else{
            send.putExtra(Intent.EXTRA_SUBJECT, "Feedback from Ms." + firstnamer + lastnamer);
        }

        send.putExtra(Intent.EXTRA_TEXT, dataEmail + "");

        startActivity(Intent.createChooser(send, "Choose a Platform"));
    }
}