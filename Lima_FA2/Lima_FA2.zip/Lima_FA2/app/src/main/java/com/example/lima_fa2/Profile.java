package com.example.lima_fa2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        TextView fname = findViewById(R.id.fnametext);
        TextView lname = findViewById(R.id.lnametext);
        TextView email = findViewById(R.id.emaillText);
        ImageView imageView2 = findViewById(R.id.imageView2);

        Bundle information = getIntent().getExtras();
        String firstname = information.getString("x_fname");
        String lastname = information.getString("x_lname");
        String emails = information.getString("x_email");
        String gender = information.getString("x_gender");

        fname.setText(firstname);
        lname.setText(lastname);
        email.setText(emails);

        if(gender.equalsIgnoreCase("MALE")){
            imageView2.setImageDrawable(getResources().getDrawable(R.drawable.knight));
        }else{
            imageView2.setImageDrawable(getResources().getDrawable(R.drawable.assassin));
        }

        Button btnbackers = findViewById(R.id.btnbackers);
        btnbackers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back = new Intent(getApplicationContext(), HomePage.class);
                startActivity(back);
            }
        });
    }
}