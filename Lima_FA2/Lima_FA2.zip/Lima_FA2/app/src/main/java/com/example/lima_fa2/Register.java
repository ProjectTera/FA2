package com.example.lima_fa2;

import static android.widget.Toast.*;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        TextView lastTxt = findViewById(R.id.feedbackTxt);
        TextView emailTxt = findViewById(R.id.emailTxt);
        TextView firstTxt = findViewById(R.id.firstTxt);
        TextView GenTxt = findViewById(R.id.GenTxt);
        Button changebtn = findViewById(R.id.changebtn);
        Button submitbtn = findViewById(R.id.btnsubmit);
        changebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentgender = GenTxt.getText().toString();
                if(currentgender.equalsIgnoreCase("MALE")){
                    GenTxt.setText("FEMALE");
                }else{
                    GenTxt.setText("MALE");
                }
            }
        });
        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentgender = GenTxt.getText().toString();
                String currentfname = firstTxt.getText().toString();
                String currentlname = lastTxt.getText().toString();
                String currentemail = emailTxt.getText().toString();

                if(currentfname.equalsIgnoreCase("")|| currentlname.equalsIgnoreCase("") || currentemail.equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"All fields must be field", LENGTH_SHORT).show();
                }else if (!Patterns.EMAIL_ADDRESS.matcher(currentemail).matches()) {
                    Toast.makeText(getApplicationContext(), "Please enter a valid email address", LENGTH_SHORT).show();
                }else{
                    profilepage(currentfname,currentlname,currentemail,currentgender);
                }

            }
        });
    }
    public void profilepage(String fname, String lname, String email, String gender){

        Intent nextpage = new Intent(getApplicationContext(), HomePage.class);
        Bundle extras = new Bundle();
        extras.putString("x_fname", fname);
        extras.putString("x_lname", lname);
        extras.putString("x_email", email);
        extras.putString("x_gender", gender);
        nextpage.putExtras(extras);
        startActivity(nextpage);
    }



}