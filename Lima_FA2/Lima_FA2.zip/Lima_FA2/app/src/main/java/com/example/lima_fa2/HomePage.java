package com.example.lima_fa2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);


        TextView hometitle = findViewById(R.id.hometitle);
        Button btnProfile= findViewById(R.id.btnProfile);
        Button btnfeedback = findViewById(R.id.btnfeedback);
        Button btnagain = findViewById(R.id.btnagain);

        Bundle information = getIntent().getExtras();
        String firstname = information.getString("x_fname");
        String lastname = information.getString("x_lname");
        String email = information.getString("x_email");
        String gender = information.getString("x_gender");

        if(gender.equalsIgnoreCase("MALE")){
            hometitle.setText("Welcome, Mr. " + firstname + " " + lastname);
        }else{
            hometitle.setText("Welcome, Ms. " + firstname + " " + lastname);
        }

        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentgender1 = gender;
                String currentfname1 = firstname;
                String currentlname1 = lastname;
                String currentemail1 = email;

                profilepage(currentfname1,currentlname1,currentemail1,currentgender1);
            }
        });

        btnfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    String currentgender2 = gender;
                    String currentfname2 = firstname;
                    String currentlname2 = lastname;
                    String currentemail2 = email;

                    feedbackRequirements(currentfname2,currentlname2,currentemail2,currentgender2);
            }
        });

        btnagain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back = new Intent(getApplicationContext(), Register.class);
                startActivity(back);
            }
        });
    }
    public void feedbackRequirements(String fname2, String lname2, String email2, String gender2){

        Intent nextpage2 = new Intent(getApplicationContext(), Feedback.class);
        Bundle extras2 = new Bundle();
        extras2.putString("x_fname2", fname2);
        extras2.putString("x_lname2", lname2);
        extras2.putString("x_email2", email2);
        extras2.putString("x_gender2", gender2);
        nextpage2.putExtras(extras2);
        startActivity(nextpage2);
    }

    public void profilepage(String fname, String lname, String email, String gender){

        Intent nextpage1 = new Intent(getApplicationContext(), Profile.class);
        Bundle extras = new Bundle();
        extras.putString("x_fname", fname);
        extras.putString("x_lname", lname);
        extras.putString("x_email", email);
        extras.putString("x_gender", gender);
        nextpage1.putExtras(extras);
        startActivity(nextpage1);
    }
}