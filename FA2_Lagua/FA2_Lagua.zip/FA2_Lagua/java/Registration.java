package com.example.fa2_lagua;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.Serializable;

public class Registration extends AppCompatActivity {

    Button btnChangeGender;
    Button btnSubmit;
    EditText etFName;
    EditText etLName;
    EditText etEmail;
    EditText etGender;

    private final String[] arrGender = {"Male", "Female"};
    private int gender = 0;
    private EditText[] fields;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registration);

        btnChangeGender = findViewById(R.id.btnChangeGender);
        btnSubmit = findViewById(R.id.btnSubmit);

        etFName = findViewById(R.id.etFName);
        etLName = findViewById(R.id.etLName);
        etEmail = findViewById(R.id.etEmail);
        etGender = findViewById(R.id.etGender);

        fields = new EditText[]{etFName, etLName, etEmail, etGender};

        btnChangeGender.setOnClickListener(view -> {
            gender = switchGender(gender);
            changeFieldText(etGender, arrGender[gender]);
        });

        btnSubmit.setOnClickListener(view -> {
            if (!emptyFields(fields))
            {
                Person person = new Person(etFName.getText().toString(), etLName.getText().toString(), etEmail.getText().toString(), etGender.getText().toString());
                goToHome(person);
            }
            else
            {
                Toast toast = Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT);
                toast.show();
            }
        });
    }

    private void changeFieldText(EditText et, String text)
    {
        et.setText(text);
    }

    private int switchGender(int state)
    {
        return Math.absExact(state - 1);
    }

    private boolean emptyInput(EditText et)
    {
        return (et.getText().toString().isEmpty() || et.getText().toString().isBlank());
    }

    private boolean emptyFields(EditText[] et)
    {
        boolean checker = false;
        for (EditText e : et) {
            if (emptyInput(e)) {
                checker = true;
                break;
            }
        }
        return checker;
    }

    private void goToHome(Person person)
    {
        Intent i = new Intent(getApplicationContext(), Home.class);
        i.putExtra("person", person);
        startActivity(i);
    }
}