package com.example.fa2_lagua;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

/*
 * May main theme
 *   - Unique bg image for each screen
 *
 * 1st screen
 *   - Touch screen to continue
 *
 * 2nd Screen
 *   - Registration
 *     - FName, LName, Email, Gender (Male, Female)
 *     - Button switches gender
 *     - Validate fields (Toast)
 *
 * 3rd Screen
 *   - Welcome message (mr/ms)
 *   - View Profile
 *   - Submit Feedback
 *   - Register Again (Back to Registration Form)
 *
 * 4th Screen
 *   - Profile (FName, LName, Email, Profile dependent on gender)
 *   - Go back (Home Page)
 *
 * 5th Screen
 *   - Submit Feedback
 *   - Submit and Cancel (Home)
 * */

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void goToRegistration(View view) {
        Intent i = new Intent(getApplicationContext(), Registration.class);
        startActivity(i);
    }
}