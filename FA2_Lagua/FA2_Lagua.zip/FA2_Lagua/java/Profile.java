package com.example.fa2_lagua;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.Serializable;
import java.util.Objects;

public class Profile extends AppCompatActivity {

    Button btnBack;
    TextView tvFName;
    TextView tvLName;
    TextView tvEmail;
    ImageView imgProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        Person person = (Person) getIntent().getSerializableExtra("person");
        tvFName = findViewById(R.id.tvFName);
        tvLName = findViewById(R.id.tvLName);
        tvEmail = findViewById(R.id.tvEmail);
        imgProfile = findViewById(R.id.imgProfile);

        if(Objects.equals(person.getCourtesyTitle(), "Mr."))
        {
            imgProfile.setImageResource(R.drawable.stark);
        }

        tvFName.setText(person.getFName());
        tvLName.setText(person.getLName());
        tvEmail.setText(person.getEmail());

        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(view -> {
            goToHome(person);
        });
    }

    private void goToHome(Person person)
    {
        Intent i = new Intent(getApplicationContext(), Home.class);
        i.putExtra("person", (Serializable) person);
        startActivity(i);
    }
}