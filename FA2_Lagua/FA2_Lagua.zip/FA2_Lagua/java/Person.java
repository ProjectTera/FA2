package com.example.fa2_lagua;

import java.io.Serializable;
import java.util.Objects;

public class Person implements Serializable {

    private String m_FName;
    private String m_LName;
    private String m_Email;
    private String m_Gender;
    private String m_CourtesyTitle;

    public Person(String fname, String lname, String email, String gender)
    {
        m_FName = fname;
        m_LName = lname;
        m_Email = email;
        m_Gender = gender;
        m_CourtesyTitle = "Ms.";

        if(Objects.equals(gender, "Male"))
            m_CourtesyTitle = "Mr.";

    }

    public String getFName()
    {
        return m_FName;
    }

    public String getLName()
    {
        return m_LName;
    }

    public String getEmail()
    {
        return m_Email;
    }

    public String getGender()
    {
        return m_Gender;
    }

    public String getCourtesyTitle()
    {
        return m_CourtesyTitle;
    }

    public void setFName(String fname)
    {
        m_FName = fname;
    }

    public void setLName(String lname)
    {
        m_LName = lname;
    }

    public void setEmail(String email)
    {
        m_Email = email;
    }

    public void setGender(String gender)
    {
        m_Gender = gender;
    }

}
