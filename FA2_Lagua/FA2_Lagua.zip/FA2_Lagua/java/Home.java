package com.example.fa2_lagua;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.Serializable;

public class Home extends AppCompatActivity {

    TextView tvWelcome;
    Button btnProfile;
    Button btnFeedback;
    Button btnRegister;
    Person person;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        tvWelcome = findViewById(R.id.tvWelcome);
        btnProfile = findViewById(R.id.btnProfile);
        btnFeedback = findViewById(R.id.btnFeedback);
        btnRegister = findViewById(R.id.btnRegister);

        person = (Person) getIntent().getSerializableExtra("person");
        String message = "Welcome, " + person.getCourtesyTitle() + " " + person.getLName();

        tvWelcome.setText(message);

        btnProfile.setOnClickListener(view -> {
            goToProfile(person);
        });

        btnFeedback.setOnClickListener(view -> {
            goToFeedback(person);
        });

        btnRegister.setOnClickListener(view -> {
            goToRegister();
        });

    }

    private void goToRegister()
    {
        Intent i = new Intent(getApplicationContext(), Registration.class);
        startActivity(i);
    }

    private void goToFeedback(Person person)
    {
        Intent i = new Intent(getApplicationContext(), Feedback.class);
        i.putExtra("person", person);
        startActivity(i);
    }

    private void goToProfile(Person person)
    {
        Intent i = new Intent(getApplicationContext(), Profile.class);
        i.putExtra("person", (Serializable) person);
        startActivity(i);
    }

}