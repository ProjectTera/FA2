package com.example.fa2_lagua;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.Serializable;

public class Feedback extends AppCompatActivity {

    Button btnSubmit;
    Button btnCancel;

    EditText etFeedback;
    String feedbackMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        btnSubmit = findViewById(R.id.btnSubmit);
        btnCancel = findViewById(R.id.btnCancel);
        etFeedback = findViewById(R.id.etFeedback);

        Person person = (Person) getIntent().getSerializableExtra("person");

        btnSubmit.setOnClickListener(view -> {
            feedbackMessage = etFeedback.getText().toString();
            if (isEmptyFeeback(feedbackMessage))
            {
                Toast toast = Toast.makeText(this, "Please give us a feedback.", Toast.LENGTH_SHORT);
                toast.show();
            }
            else
                sendFeedback();
        });

        btnCancel.setOnClickListener(view -> {
            goToHome(person);
        });
    }

    private boolean isEmptyFeeback(String message)
    {
        return (message.isEmpty() || message.isBlank());
    }

    private void sendFeedback()
    {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");

        i.putExtra(Intent.EXTRA_SUBJECT, "Feedback Review");
        i.putExtra(Intent.EXTRA_TEXT, feedbackMessage);

        startActivity(Intent.createChooser(i, "Choose a Platform"));
    }

    private void goToHome(Person person)
    {
        Intent i = new Intent(getApplicationContext(), Home.class);
        i.putExtra("person", (Serializable) person);
        startActivity(i);
    }
}