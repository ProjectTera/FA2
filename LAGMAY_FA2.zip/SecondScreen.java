package com.example.fa2;

import android.os.Bundle;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SecondScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_screen);
        Button btnsubmit = findViewById(R.id.btnsubmit);
        Button btngender = findViewById(R.id.btngender);
        TextView textView6 = findViewById(R.id.textView6);
        EditText editTextText2 = findViewById(R.id.editTextText2); //firstname
        EditText editTextText4 = findViewById(R.id.editTextText4); //lastname
        EditText editTextText3 = findViewById(R.id.editTextText3); //email
        Intent a = getIntent();
        Intent i = getIntent();
        btngender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView textView6 = findViewById(R.id.textView6);

                if (textView6.getText().toString().equals("Male")){
                    textView6.setText("Female");
                }else {
                    textView6.setText("Male");
                };
            }
        });
        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editTextText2.getText().toString().equals("") || editTextText3.getText().toString().equals("") || editTextText4.getText().toString().equals("") ){
                    Toast.makeText(SecondScreen.this, "Fill up the empty field!", Toast.LENGTH_SHORT).show();
                }else {
                String firstname = editTextText2.getText().toString();
                String email = editTextText3.getText().toString();
                String lastname = editTextText4.getText().toString();
                String gender = textView6.getText().toString();
                gotToThirdActivity(firstname,lastname,email,gender);
                };
            }
        });


    }
    public void gotToThirdActivity(String fn, String ln, String email, String Gender){
        Intent j = new Intent(getApplicationContext(),ThirdScreen.class);
        j.putExtra("fn",fn);
        j.putExtra("ln",ln);
        j.putExtra("email",email);
        j.putExtra("gender",Gender);
        startActivity(j);
    }
}