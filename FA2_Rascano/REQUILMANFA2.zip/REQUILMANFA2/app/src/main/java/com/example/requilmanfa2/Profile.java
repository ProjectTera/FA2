package com.example.requilmanfa2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Profile extends AppCompatActivity {

    public TextView firstNameET, lastNameET, emailET;
    public ImageView profilePicIV;
    public Person person;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        firstNameET = findViewById(R.id.firstNameET);
        lastNameET = findViewById(R.id.lastNameET);
        emailET = findViewById(R.id.emailET);

        profilePicIV = findViewById(R.id.profilePicIV);

        fetchExtras(getIntent());

        firstNameET.setText("FIRST NAME\n" + person.getFirstName());
        lastNameET.setText("LAST NAME\n" + person.getLastName());
        emailET.setText("EMAIL\n" + person.getEmail());

    }

    public void fetchExtras(Intent i) {
        person = new Person(i);
    }
}