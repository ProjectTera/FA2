package com.example.requilmanfa2;

import android.content.Intent;

public class Person {
    private String firstName;
    private String lastName;
    private String email;
    private String gender;

    public Person(Intent i) {
        this.setFirstName(i.getStringExtra("firstName"));
        this.setLastName(i.getStringExtra("lastName"));
        this.setEmail(i.getStringExtra("email"));
        this.setGender(i.getStringExtra("gender"));
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
