package com.example.requilmanfa2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class RegisterActivity extends AppCompatActivity {

    public EditText firstNameET, lastNameET, genderET, emailET;
    public Button submitBtn, changeGenderBtn;
    public boolean isMale;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        isMale = true;

        firstNameET = findViewById(R.id.firstNameET);
        lastNameET = findViewById(R.id.lastNameET);
        genderET = findViewById(R.id.genderET);
        changeGenderBtn = findViewById(R.id.changeGenderBtn);
        emailET = findViewById(R.id.emailET);
        submitBtn = findViewById(R.id.submitBtn);

        changeGenderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isMale) {
                    isMale = false;
                    genderET.setText("Female");
                } else {
                    isMale = true;
                    genderET.setText("Male");
                }
            }
        });

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validateFields()) {
                    Intent i = new Intent(getApplicationContext(), Home.class);
                    i.putExtra("firstName", firstNameET.getText().toString());
                    i.putExtra("lastName", lastNameET.getText().toString());
                    i.putExtra("email", emailET.getText().toString());
                    i.putExtra("gender", genderET.getText().toString());

                    startActivity(i);
                }
            }
        });
    }

    public boolean validateFields() {
        if (firstNameET.getText().toString().isEmpty()
                || lastNameET.getText().toString().isEmpty()
                || emailET.getText().toString().isEmpty()) {
            Toast.makeText(this
                    , "All Fields must be filled"
                    , Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}