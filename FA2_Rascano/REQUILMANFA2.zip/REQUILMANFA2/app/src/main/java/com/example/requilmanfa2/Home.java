package com.example.requilmanfa2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Home extends AppCompatActivity {

    public TextView textView;
    public Button viewProfileBtn, submitFeedbackBtn, registerBtn;
    public Person person;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        textView = findViewById(R.id.textView);
        viewProfileBtn = findViewById(R.id.viewProfileBtn);
        submitFeedbackBtn = findViewById(R.id.submitFeedbackBtn);
        registerBtn = findViewById(R.id.registerBtn);

        fetchExtras(getIntent());

        String prefix = "Mr.";

        if (!gender.equalsIgnoreCase("Male")) {
            prefix = "Ms.";
        }

        textView.setText("Welcome, " + prefix + " " + firstName + " " + lastName);

        viewProfileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Profile.class);
                i.putExtra("firstName", firstName);
                i.putExtra("lastName", lastName);
                i.putExtra("email", email);
                i.putExtra("gender", gender);

                startActivity(i);
            }
        });

        submitFeedbackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(i);
            }
        });


    }

    public void fetchExtras(Intent i) {
        person = new Person(i);
    }
}