package com.example.fa2_rascano;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        TextView tvName = findViewById(R.id.tvName);
        Intent i = getIntent();
        String fName = i.getStringExtra("fName");
        String lName = i.getStringExtra("lName");
        String email = i.getStringExtra("email");
        String gender = i.getStringExtra("gender");
        String title="";
        if (gender.equals("Male")){
            title = "Mr.";
        }else if (gender.equals("Female")){
            title = "Ms.";
        }
        tvName.setText("Welcome " + title + " " + fName + " " + lName);

        Button btnProfile = findViewById(R.id.btnProfile);
        Button btnFeedback = findViewById(R.id.btnFeedback);
        Button btnRegister = findViewById(R.id.btnRegister);

        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Profile.class);
                i.putExtra("fName", fName);
                i.putExtra("lName", lName);
                i.putExtra("email", email);
                i.putExtra("gender", gender);
                startActivity(i);
            }
        });

        btnFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Feedback.class);
                startActivity(i);
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Registration.class);
                startActivity(i);
            }
        });
    }
}