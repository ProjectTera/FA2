package com.example.fa2_rascano;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Registration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        EditText edtxtFirstName = findViewById(R.id.edtxtFirstName);
        EditText edtxtLastName = findViewById(R.id.edtxtLastName);
        EditText edtxtEmail = findViewById(R.id.edtxtEmail);
        EditText edtxtGender = findViewById(R.id.edtxtGender);

        Button btnGender = findViewById(R.id.btnGender);
        btnGender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentVal = String.valueOf(edtxtGender.getText());
                if(currentVal.equals("Male")){
                    edtxtGender.setText("Female");
                }else if (currentVal.equals("Female")){
                    edtxtGender.setText("Male");
                }
            }
        });

        Button btnSubmit = findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {


                if (edtxtFirstName.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Please enter first name", Toast.LENGTH_SHORT).show();
                }
                if (edtxtLastName.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Please enter last name", Toast.LENGTH_SHORT).show();
                }
                if (edtxtEmail.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Please enter email", Toast.LENGTH_SHORT).show();
                }

                if(!edtxtFirstName.getText().toString().equals("")
                        && !edtxtLastName.getText().toString().equals("")
                        && !edtxtEmail.getText().toString().equals("")){
                        Intent i = new Intent(getApplicationContext(), HomePage.class);
                        i.putExtra("fName", edtxtFirstName.getText().toString());
                        i.putExtra("lName", edtxtLastName.getText().toString());
                        i.putExtra("email", edtxtEmail.getText().toString());
                        i.putExtra("gender", edtxtGender.getText().toString());
                        startActivity(i);
                }
            }
        });
    }
}