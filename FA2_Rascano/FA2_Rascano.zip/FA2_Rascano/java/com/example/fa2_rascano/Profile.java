package com.example.fa2_rascano;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        TextView tvFName = findViewById(R.id.tvFName);
        TextView tvLName = findViewById(R.id.tvLName);
        TextView tvEmail = findViewById(R.id.tvEmail);
        ImageView imgviewProfile = findViewById(R.id.imgviewProfile);

        Intent i = getIntent();
        String fName = i.getStringExtra("fName");
        String lName = i.getStringExtra("lName");
        String email = i.getStringExtra("email");
        String gender = i.getStringExtra("gender");

        if (gender.equals("Male")){
//            imgviewProfile.setBackground(Drawable.createFromPath("@drawable/p_male"));
//            imgviewProfile.setBackground(getResources().getDrawable(R.drawable.p_male, getApplicationContext().getTheme()));
            imgviewProfile.setImageDrawable(getResources().getDrawable(R.drawable.p_male, getApplicationContext().getTheme()));
        }else if (gender.equals("Female")){
            imgviewProfile.setImageDrawable(getResources().getDrawable(R.drawable.p_female, getApplicationContext().getTheme()));
        }

        tvFName.setText(fName + "");
        tvLName.setText(lName + "");
        tvEmail.setText(email + "");

        Button btnHome = findViewById(R.id.btnHome);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), HomePage.class);
                startActivity(i);
            }
        });


    }
}