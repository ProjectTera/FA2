package com.example.fa2_delrosario;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class landingPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_page);
        Intent j = getIntent();
        String lname = j.getStringExtra("ln");
        String fname = j.getStringExtra("fn");
        String mail = j.getStringExtra("email");
        String sex = j.getStringExtra("sex");

        TextView welcome = findViewById(R.id.txtWelcome);
        Button viewProfile = findViewById(R.id.viewProfile);
        Button submitFeedback = findViewById(R.id.submitFeedback);
        Button registerAgain = findViewById(R.id.registerAgain);

        viewProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendToOther(lname,fname,mail,sex);
            }
        });

        submitFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(getApplication(), feedback.class);
                startActivity(a);
            }
        });

        registerAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(getApplication() , registration.class);
                startActivity(a);
            }
        });

        if(sex.equals("Female")){
            welcome.setText("Welcome Ms. "+fname + " !");
        }else{
            welcome.setText("Welcome Mr. "+fname + " !");
        }

    }

    public void sendToOther(String ln, String fn, String email, String gender){
        Intent j = new Intent(getApplicationContext(), profile.class);
        j.putExtra("ln", ln);
        j.putExtra("fn", fn);
        j.putExtra("email", email);
        j.putExtra("sex", gender);
        startActivity(j);
    }
}