package com.example.fa2_delrosario;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        Intent j = getIntent();
        String lname = j.getStringExtra("ln");
        String fname = j.getStringExtra("fn");
        String mail = j.getStringExtra("email");
        String sex = j.getStringExtra("sex");

        TextView lastName = findViewById(R.id.lastName);
        TextView firstName = findViewById(R.id.firstName);
        TextView email = findViewById(R.id.email);
        TextView gender = findViewById(R.id.gender);
        Button btnBack = findViewById(R.id.btnBack);
        ImageView male = findViewById(R.id.male);

        lastName.setText(lname);
        firstName.setText(fname);
        email.setText(mail);
        gender.setText(sex);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(getApplication(), landingPage.class);
                startActivity(a);
            }
        });
        if(sex.equals("Male")){
            male.setVisibility(View.VISIBLE);
        }else{
            male.setVisibility(View.INVISIBLE);
        }

    }
}