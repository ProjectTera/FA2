package com.example.fa2_delrosario;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class registration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        EditText lastName = findViewById(R.id.lastName);
        EditText firstName = findViewById(R.id.firstName);
        EditText email = findViewById(R.id.email);
        TextView gender = findViewById(R.id.gender);
        Button btnGender = findViewById(R.id.btnHome);
        Button submit = findViewById(R.id.btnSubmit);
        Button btnBack = findViewById(R.id.btnBack);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(lastName.getText().toString().equals("") || firstName.getText().toString().equals("") || email.getText().toString().equals("")){
                    Toast.makeText(registration.this, "Fill up all fields", Toast.LENGTH_SHORT).show();
                } else if (email.getText().toString().matches(emailPattern)) {
                    String lname = lastName.getText().toString();
                    String fname = firstName.getText().toString();
                    String mail = email.getText().toString();
                    String sex = gender.getText().toString();
                    sendToOther(lname,fname,mail,sex);
                    Toast.makeText(registration.this, "Account created!", Toast.LENGTH_SHORT).show();
                } else{
                    Toast.makeText(registration.this, "Invalid email", Toast.LENGTH_SHORT).show();
                }
            }
        });


        btnGender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (gender.getText().toString().equals("Male")){
                    gender.setText("Female");
                } else{
                    gender.setText("Male");
                }
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(getApplication(), MainActivity.class);
                startActivity(a);
            }
        });

    }

    public void sendToOther(String ln, String fn, String email, String gender){
        Intent j = new Intent(getApplicationContext(), landingPage.class);
        j.putExtra("ln", ln);
        j.putExtra("fn", fn);
        j.putExtra("email", email);
        j.putExtra("sex", gender);
        startActivity(j);
    }


}